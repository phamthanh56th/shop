<?php get_header(); 
the_post();
	the_content(); ?>
<?php get_footer(); ?>